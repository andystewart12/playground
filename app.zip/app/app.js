var http = require('http');
var fs = require('fs');
var express = require('express');
var path = require('path');
var bodyParser = require('body-parser');
var handlebars = require('express-handlebars');
var session = require('client-sessions');
var user = require('./models/user.js');

var app = express();
app.session = require('client-sessions');
app.session.user = require('./models/user.js');

// set up view engine
var hbs = handlebars.create({
    // no default layout, set app layout in res.render
    layoutsDir: './views/layouts',
    extname: '.html',
    folder: 'private'
});

app.engine('html', hbs.engine);
app.set('view engine', 'html');
app.set('views', path.join(__dirname, 'views'));

// set up JSON parsers
app.use( bodyParser.json() );       // to support JSON-encoded bodies
app.use(bodyParser.urlencoded({     // to support URL-encoded bodies
  extended: true
}));

// static files
//app.use(express.static('app/views'));
app.use(express.static('scripts'));
app.use(express.static('content'));
app.use(express.static('models'));

app.use('/home', authFilter);
app.use('/test', authFilter);

// dynamically include routes (Controller)
fs.readdirSync('./controllers').forEach(function (file) {
  if(file.substr(-3) == '.js') {
      route = require('./controllers/' + file);
      route.controller(app);
  }
});

app.use(session({
    cookieName: 'session',
    secret: 'thisisasecret',
    duration: 30 * 60 * 1000,
    activeDuration: 10 * 60 * 1000,
    httpOnly: true,
    secure: true,
    ephemural: true
}));

function authFilter (req, res, next) {
    if (!app.user) {
        res.redirect('/');
    } else {
        next();
    }
}

function normalizePort(val) {
  var port = parseInt(val, 10);

  if (isNaN(port)) {
    // named pipe
    return val;
  }

  if (port >= 0) {
    // port number
    return port;
  }

  return false;
}

var port = normalizePort(process.env.PORT || '3000');
app.set('port', port);

var server = http.createServer(app);
server.listen(port);

// start server on port 8081
//app.set('port', port);
//console.log('Server running at http://127.0.0.1:' + port);